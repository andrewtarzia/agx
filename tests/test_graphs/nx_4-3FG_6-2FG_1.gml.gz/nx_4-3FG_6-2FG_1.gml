graph [
  node [
    id 0
    label "0"
    type 3
  ]
  node [
    id 1
    label "8"
    type 2
  ]
  node [
    id 2
    label "9"
    type 2
  ]
  node [
    id 3
    label "7"
    type 2
  ]
  node [
    id 4
    label "1"
    type 3
  ]
  node [
    id 5
    label "4"
    type 2
  ]
  node [
    id 6
    label "5"
    type 2
  ]
  node [
    id 7
    label "6"
    type 2
  ]
  node [
    id 8
    label "2"
    type 3
  ]
  node [
    id 9
    label "3"
    type 3
  ]
  edge [
    source 0
    target 1
  ]
  edge [
    source 0
    target 2
  ]
  edge [
    source 0
    target 3
  ]
  edge [
    source 1
    target 8
  ]
  edge [
    source 2
    target 9
  ]
  edge [
    source 3
    target 8
  ]
  edge [
    source 4
    target 5
  ]
  edge [
    source 4
    target 6
  ]
  edge [
    source 4
    target 7
  ]
  edge [
    source 5
    target 9
  ]
  edge [
    source 6
    target 9
  ]
  edge [
    source 7
    target 8
  ]
]
