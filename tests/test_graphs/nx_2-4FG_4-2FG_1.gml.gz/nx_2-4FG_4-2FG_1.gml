graph [
  node [
    id 0
    label "0"
    type 4
  ]
  node [
    id 1
    label "5"
    type 2
  ]
  node [
    id 2
    label "3"
    type 2
  ]
  node [
    id 3
    label "2"
    type 2
  ]
  node [
    id 4
    label "4"
    type 2
  ]
  node [
    id 5
    label "1"
    type 4
  ]
  edge [
    source 0
    target 1
  ]
  edge [
    source 0
    target 2
  ]
  edge [
    source 0
    target 3
  ]
  edge [
    source 0
    target 4
  ]
  edge [
    source 1
    target 5
  ]
  edge [
    source 2
    target 5
  ]
  edge [
    source 3
    target 5
  ]
  edge [
    source 4
    target 5
  ]
]
