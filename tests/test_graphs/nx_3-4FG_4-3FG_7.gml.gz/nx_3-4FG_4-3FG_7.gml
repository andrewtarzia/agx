graph [
  multigraph 1
  node [
    id 0
    label "0"
  ]
  node [
    id 1
    label "5"
  ]
  node [
    id 2
    label "4"
  ]
  node [
    id 3
    label "1"
  ]
  node [
    id 4
    label "3"
  ]
  node [
    id 5
    label "6"
  ]
  node [
    id 6
    label "2"
  ]
  edge [
    source 0
    target 1
    key 0
  ]
  edge [
    source 0
    target 1
    key 1
  ]
  edge [
    source 0
    target 2
    key 0
  ]
  edge [
    source 0
    target 2
    key 1
  ]
  edge [
    source 1
    target 3
    key 0
  ]
  edge [
    source 2
    target 3
    key 0
  ]
  edge [
    source 3
    target 4
    key 0
  ]
  edge [
    source 3
    target 5
    key 0
  ]
  edge [
    source 4
    target 6
    key 0
  ]
  edge [
    source 4
    target 6
    key 1
  ]
  edge [
    source 5
    target 6
    key 0
  ]
  edge [
    source 5
    target 6
    key 1
  ]
]
