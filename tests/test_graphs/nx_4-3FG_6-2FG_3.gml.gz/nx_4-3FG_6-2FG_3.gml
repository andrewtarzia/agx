graph [
  multigraph 1
  node [
    id 0
    label "0"
    type 3
  ]
  node [
    id 1
    label "7"
    type 2
  ]
  node [
    id 2
    label "8"
    type 2
  ]
  node [
    id 3
    label "1"
    type 3
  ]
  node [
    id 4
    label "5"
    type 2
  ]
  node [
    id 5
    label "4"
    type 2
  ]
  node [
    id 6
    label "2"
    type 3
  ]
  node [
    id 7
    label "9"
    type 2
  ]
  node [
    id 8
    label "3"
    type 3
  ]
  node [
    id 9
    label "6"
    type 2
  ]
  edge [
    source 0
    target 1
    key 0
  ]
  edge [
    source 0
    target 1
    key 1
  ]
  edge [
    source 0
    target 2
    key 0
  ]
  edge [
    source 2
    target 3
    key 0
  ]
  edge [
    source 3
    target 4
    key 0
  ]
  edge [
    source 3
    target 5
    key 0
  ]
  edge [
    source 4
    target 8
    key 0
  ]
  edge [
    source 5
    target 6
    key 0
  ]
  edge [
    source 6
    target 7
    key 0
  ]
  edge [
    source 6
    target 7
    key 1
  ]
  edge [
    source 8
    target 9
    key 0
  ]
  edge [
    source 8
    target 9
    key 1
  ]
]
