graph [
  multigraph 1
  node [
    id 0
    label "2"
    type 4
  ]
  node [
    id 1
    label "4"
    type 4
  ]
  node [
    id 2
    label "1"
    type 4
  ]
  node [
    id 3
    label "3"
    type 4
  ]
  node [
    id 4
    label "0"
    type 4
  ]
  edge [
    source 0
    target 1
    key 0
  ]
  edge [
    source 0
    target 4
    key 0
  ]
  edge [
    source 0
    target 4
    key 1
  ]
  edge [
    source 0
    target 3
    key 0
  ]
  edge [
    source 1
    target 2
    key 0
  ]
  edge [
    source 1
    target 2
    key 1
  ]
  edge [
    source 1
    target 3
    key 0
  ]
  edge [
    source 2
    target 3
    key 0
  ]
  edge [
    source 2
    target 4
    key 0
  ]
  edge [
    source 3
    target 4
    key 0
  ]
]
